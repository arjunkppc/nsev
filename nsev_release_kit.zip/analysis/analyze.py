import json, collections, numpy as np
out = {}
POL = ['nocoord', 'reactive', 'pace_cv', 'pace_social', 'pace_eva']
def load(f):
    by = collections.defaultdict(dict)
    for l in open(f):
        r = json.loads(l); by[(r['scene'], r['inj'])][r['policy']] = r
    return {k: v for k, v in by.items() if 'nocoord' in v and all(p in v for p in POL)}
def boot(by, a, b, m, B=4000, mask=None):
    keys = [k for k in by if (mask is None or mask(by[k]))]
    scenes = sorted({k[0] for k in keys}); sidx = {s: i for i, s in enumerate(scenes)}
    sid = np.array([sidx[k[0]] for k in keys]); d = np.array([by[k][a][m] - by[k][b][m] for k in keys])
    rng = np.random.default_rng(0); bt = rng.integers(0, len(scenes), (B, len(scenes)))
    tot = np.bincount(sid, d, len(scenes)); cnt = np.bincount(sid, None, len(scenes))
    s = tot[bt].sum(1) / np.maximum(cnt[bt].sum(1), 1); lo, hi = np.percentile(s, [2.5, 97.5])
    return dict(diff=float(d.mean()), lo=float(lo), hi=float(hi), sig=bool(hi < 0 or lo > 0), n=len(keys), scenes=len(scenes))
M = ['ev_delay', 'ev_speed', 'lost_m', 'disturbed', 'commands', 'cmd_conflicts', 'civ_conflicts', 'ev_hb', 'ev_stops', 'min_ttc', 'coll_sim', 'coll_logged', 'plan_ms']
CL = {}
for tag, f in [('0.25', 'cl_test_rho0.25.jsonl'), ('0.5', 'cl_test_rho0.5.jsonl'), ('1.0', 'cl_test_rho1.0.jsonl'), ('0.5_TL8', 'cl_test_rho0.5_TL8.jsonl')]:
    by = load(f); t = {}
    for p in POL:
        t[p] = {m: float(np.mean([by[k][p][m] for k in by])) for m in M}
        t[p]['runs_coll_sim'] = int(sum(by[k][p]['coll_sim'] > 0 for k in by)); t[p]['runs_coll_logged'] = int(sum(by[k][p]['coll_logged'] > 0 for k in by))
    cmp = {}
    for p in POL[1:]:
        for ref in ['nocoord', 'reactive']:
            if p == ref: continue
            for m in ['ev_delay', 'lost_m', 'cmd_conflicts', 'coll_sim', 'ev_hb', 'disturbed']:
                cmp[f'{p}-{ref}:{m}'] = boot(by, p, ref, m)
    # per city
    city = {}
    for c, fn in [('boston', lambda v: v['nocoord']['location'].startswith('boston')), ('singapore', lambda v: v['nocoord']['location'].startswith('singapore'))]:
        city[c] = {'n': sum(fn(by[k]) for k in by), 'nocoord_delay': float(np.mean([by[k]['nocoord']['ev_delay'] for k in by if fn(by[k])])),
                   'eva-nocoord': boot(by, 'pace_eva', 'nocoord', 'ev_delay', mask=fn), 'reactive-nocoord': boot(by, 'reactive', 'nocoord', 'ev_delay', mask=fn),
                   'eva-reactive:delay': boot(by, 'pace_eva', 'reactive', 'ev_delay', mask=fn), 'eva-reactive:cmd_conf': boot(by, 'pace_eva', 'reactive', 'cmd_conflicts', mask=fn)}
    CL[tag] = dict(n=len(by), scenes=len({k[0] for k in by}), table=t, cmp=cmp, city=city)
out['closed_loop'] = CL
out['dev'] = {}
for TL in [8, 15, 30]:
    by = load(f'cl_dev_TL{TL}_TH0.3.jsonl') if False else None
for TL in [8, 15, 30]:
    R = [json.loads(l) for l in open(f'cl_dev_TL{TL}_TH0.3.jsonl')]
    g = lambda p, m: float(np.mean([r[m] for r in R if r['policy'] == p]))
    out['dev'][TL] = {p: {m: g(p, m) for m in ['ev_delay', 'cmd_conflicts', 'lost_m']} for p in ['nocoord', 'reactive', 'pace_cv', 'pace_eva']}
    out['dev'][TL]['n'] = sum(r['policy'] == 'nocoord' for r in R)
# datasets
DS = {}
for f in ['nsev_train', 'nsev_val', 'nsev_test', 'stressA', 'stressB', 'stressC', 'stressD']:
    L = json.load(open(f + '_log.json')); V = [l for l in L if 'discarded' not in l]
    DS[f] = dict(replays=len(L), valid=len(V), **{k: v for k, v in collections.Counter(l['discarded'] for l in L if 'discarded' in l).items()},
                 samples=int(sum(l['samples'] for l in V)), ev_speed=float(np.mean([l['ev_mean_speed'] for l in V])),
                 takeovers=float(np.mean([l['takeovers'] for l in V])), route_len=float(np.mean([l['route_len'] for l in V])),
                 scenes=len({l['scene'] for l in V}), boston=sum(l['location'].startswith('boston') for l in V))
Z = np.load('nsev_test.npz'); DS['nsev_test']['reacting_share'] = float(Z['reacted'].mean())
out['datasets'] = DS
out['pred'] = json.load(open('res_pred_nsev.json')); out['ci'] = json.load(open('ci_results.json'))
out['stress'] = {f'{tag}_{T}': json.load(open(f'ci_{tag}_{T}.json')) for tag in ['orig', 'dr'] for T in ['nsev_test', 'stressA', 'stressB', 'stressC', 'stressD']}
json.dump(out, open('analysis.json', 'w'), indent=1)
# print key summary
for tag, c in CL.items():
    print(f'\n== rho {tag}: {c["n"]} runs, {c["scenes"]} scenes')
    for p in POL: t = c['table'][p]; print(f'  {p:12s} delay {t["ev_delay"]:.3f} lost {t["lost_m"]:.2f} cmdconf {t["cmd_conflicts"]:.3f} cmds {t["commands"]:.3f} coll_sim runs {t["runs_coll_sim"]} logged runs {t["runs_coll_logged"]} plan {t["plan_ms"]:.3f}ms')
    for k in ['pace_eva-reactive:ev_delay', 'pace_eva-reactive:cmd_conflicts', 'pace_eva-reactive:lost_m', 'pace_eva-nocoord:ev_delay', 'pace_eva-nocoord:lost_m', 'pace_eva-pace_cv:ev_delay' if False else 'pace_cv-reactive:ev_delay']:
        v = c['cmp'][k]; print(f'   {k:34s} {v["diff"]:+.3f} [{v["lo"]:+.3f},{v["hi"]:+.3f}] {"*" if v["sig"] else ""}')
    for cty, v in c['city'].items(): print(f'   {cty}: n={v["n"]} base {v["nocoord_delay"]:.2f} eva-noc {v["eva-nocoord"]["diff"]:+.2f}{"*" if v["eva-nocoord"]["sig"] else ""} eva-reac delay {v["eva-reactive:delay"]["diff"]:+.3f}{"*" if v["eva-reactive:delay"]["sig"] else ""} cmdconf {v["eva-reactive:cmd_conf"]["diff"]:+.3f}{"*" if v["eva-reactive:cmd_conf"]["sig"] else ""}')
print('\n', json.dumps(DS, indent=0)[:1500])
