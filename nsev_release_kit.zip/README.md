# NS-EV: Emergency-Vehicle-Aware Trajectory Prediction and Disruption-Aware Corridor Coordination on Real Traffic

Code for the paper *"Emergency-Vehicle-Aware Trajectory Prediction and Disruption-Aware Corridor Coordination on Real Traffic"*.

NS-EV injects a siren-on emergency vehicle (EV) into real nuScenes traffic, makes the recorded drivers respond to it through a stochastic driver-response model, trains **EVA-Net** (an EV-aware multimodal trajectory predictor) on the resulting replays, and uses its forecasts in **PACE**, a just-in-time V2X coordinator that is evaluated in closed loop on the same replays.

![NS-EV framework](docs/figures/fig1_framework.png)

## Where each stage of Fig. 1 lives in the code

| Stage | What it does | Code |
| --- | --- | --- |
| 1. Real traffic scenes | Load nuScenes tracks, interpolate to 10 Hz | `src/nsev_pipeline.py` (`load_scene_tracks`, `resample`) |
| 2. EV injection | Frenet route from a real vehicle path, IDM-controlled EV | `src/nsev_pipeline.py` (`Route`, `build_route`, `inject`), `src/sim.py` (`idm`) |
| 3. Reactive log replay | Driver-response model: prompt / late / stubborn, panic, yielding | `src/nsev_pipeline.py` (`inject`) |
| 4. Validity filter | Discard spawn and log conflicts | `src/nsev_pipeline.py` (`__main__`) |
| 5. NS-EV dataset | Agent-centric samples, features, labels | `src/nsev_pipeline.py` (`extract_samples`), `src/features.py` |
| 6. EVA-Net | Deep model, training, reference models | `src/model.py`, `src/train.py` |
| 7. PACE coordination | Closed-loop replay, PACE and Reactive-V2X policies, T_lead selection | `src/nsev_closedloop.py`, `src/select_tl.py` |
| 8. Evaluation | Prediction metrics, bootstrap CIs, closed-loop summaries, figures | `src/eval_pred.py`, `src/compute_ci.py`, `src/summarize_cl.py`, `analysis/` |

EVA-Net architecture (Fig. 3 of the paper): `docs/figures/fig3_evanet_architecture.png`. The `.drawio` files in `docs/figures/` are the editable sources of Figs. 1 and 3.

## Installation

Python 3.9 or newer. Only CPU is needed.

```bash
pip install -r requirements.txt
```

`environment.txt` lists the exact versions used for the paper.

## Data

Download **nuScenes v1.0-trainval** (metadata and annotations are sufficient; camera and lidar data are not used) from https://www.nuscenes.org/ and unpack it so that `/path/to/nuscenes/v1.0-trainval/` exists. nuScenes is not redistributed here; its terms of use apply.

## Reproduce all results

```bash
DATAROOT=/path/to/nuscenes bash scripts/run_all.sh
# on a SLURM cluster:
sbatch --export=ALL,DATAROOT=/path/to/nuscenes scripts/run_all.sh
```

The script is resumable (finished steps are skipped) and writes everything to `work/`. It runs, in order:

1. NS-EV train / validation / test datasets (Stages 1-5)
2. EVA-Net (K = 6, K = 1), Social-Attn and MLP, three seeds each, 30 epochs (Stage 6)
3. Open-loop prediction metrics and scene-bootstrap confidence intervals
4. Domain-randomised dataset and models
5. Stress-test sets A-D and their confidence intervals
6. Closed-loop development runs and the pre-registered T_lead selection
7. Closed-loop test runs at CV penetrations 0.25, 0.5 and 1.0 (Stages 7-8)
8. Summary tables (`cl_test_summary.txt`), `analysis.json` and the result figures in `work/figs/`

The full run took about 6 hours on 8 CPU cores.

Single steps, for example:

```bash
export PYTHONPATH=$PWD/src
python src/nsev_pipeline.py --dataroot $DATAROOT --split val --out nsev_test.npz --injections 3 --seed 2
python src/train.py pace 6 30 nsev_train.npz nsev_val.npz nsev_s0_model_pace_K6.pkl 0
python src/nsev_closedloop.py --dataroot $DATAROOT --split val --rho 0.5 --injections 3 --t_lead 15 --theta_r 0.3 \
       --eva nsevdr_s0_model_pace_K6.pkl --social nsevdr_s0_model_social_K6.pkl --out cl_test_rho0.5.jsonl
```

## Figure files and paper figure numbers

| File in `work/figs/` | Paper |
| --- | --- |
| `fig02_dataset.png` | Fig. 2 |
| `fig03_training.png` | Fig. 4 |
| `fig04_prediction.png` | Fig. 5 |
| `fig05_strata.png` | Fig. 6 |
| `fig07_qualitative.png` | Fig. 7 |
| `fig06_stress.png` | Fig. 8 |
| `fig08_closedloop_rho.png` | Fig. 9 |
| `fig09_pace_vs_reactive.png` | Fig. 10 |
| `fig10_tradeoff.png` | Fig. 11 |
| `fig11_city.png` | Fig. 12 |
| `fig12_safety.png` | Fig. 13 |

Figs. 1 and 3 are the diagrams in `docs/figures/`. `fig01_pipeline.png` is an earlier sketch and is not used in the paper.

## Repository layout

```
src/        pipeline, model, training, closed loop, evaluation
scripts/    run_all.sh - reproduces the paper end to end
analysis/   statistics (analyze.py) and figures (figs.py, fig7.py)
tools/      nuScenes emergency-vehicle census and collision diagnostics
docs/       framework and architecture diagrams (PNG + editable draw.io)
results/    (optional) result files of the paper run
models/     (optional) trained models of the paper run
```

## Citation

If you use this code, please cite the paper (reference to be added on publication).

## License

To be added by the authors.
