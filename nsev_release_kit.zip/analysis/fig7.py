import numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from model import Predictor; from train import load
plt.rcParams.update({'font.family': 'DejaVu Serif', 'font.size': 9})
D = load('nsev_test.npz', 'pace'); DS = load('nsev_test.npz', 'social'); Z = np.load('nsev_test.npz')
y = D['y']; lat = np.abs(y[:, -1, 1] * 3.5)
cand = np.where((Z['reacted'] == 1) & (lat > 1.5))[0]
me = Predictor.load('nsev_s0_model_pace_K6.pkl'); ms = Predictor.load('nsev_s0_model_social_K6.pkl')
a = [D[k][cand] for k in ('hist', 'ev', 'nb', 'mask', 'prior')]; b = [DS[k][cand] for k in ('hist', 'ev', 'nb', 'mask', 'prior')]
te, pe = me.predict(*a); ts, ps = ms.predict(*b)
SC = np.array([10, 3.5]); Y = y[cand] * SC
fe = np.linalg.norm(te * SC - Y[:, None], axis=-1)[..., -1].min(1); fs = np.linalg.norm(ts * SC - Y[:, None], axis=-1)[..., -1].min(1)
rng = np.random.default_rng(3); pick = rng.choice(len(cand), 4, replace=False)   # random, not cherry-picked
fig, ax = plt.subplots(1, 4, figsize=(13, 3.2))
for a_, i in zip(ax, pick):
    h = D['hist'][cand[i]]; a_.plot(h[[0, 3, 6, 9]] * 10, h[[1, 4, 7, 10]] * 3.5, 'k-o', ms=3, label='history (2 s)')
    a_.plot(np.r_[0, Y[i, :, 0]], np.r_[0, Y[i, :, 1]], 'g-', lw=2.4, label='ground truth (3 s)')
    for k in range(6):
        t = te[i, k] * SC; a_.plot(np.r_[0, t[:, 0]], np.r_[0, t[:, 1]], '-', color='#c0392b', alpha=min(1, .15 + pe[i, k]), lw=.8 + 2.2 * pe[i, k], label='EVA-Net modes' if k == 0 else None)
        t = ts[i, k] * SC; a_.plot(np.r_[0, t[:, 0]], np.r_[0, t[:, 1]], '--', color='#9b6fc2', alpha=min(1, .15 + ps[i, k]), lw=.6 + 1.6 * ps[i, k], label='Social-Attn modes' if k == 0 else None)
    ev = D['ev'][cand[i]]; ex, ey = ev[0] * 100, ev[1] * 3.5
    a_.annotate(f'EV {abs(ex):.0f} m behind', (-20, ey), color='orange', fontsize=7.5) if ex < -22 else a_.plot(ex, ey, 's', color='orange', ms=8, label='EV')
    a_.set_title(f'minFDE: EVA {fe[i]:.2f} m | Social {fs[i]:.2f} m', fontsize=8); a_.set_xlabel('s (m, along EV route)'); a_.set_xlim(-22, 45); a_.set_ylim(-5, 5); a_.grid(alpha=.3)
ax[0].set_ylabel('d (m, lateral)'); ax[0].legend(frameon=False, fontsize=6.5, loc='lower left')
plt.tight_layout(); plt.savefig('figs/fig07_qualitative.png', dpi=200)
print('random examples; mean over all reacting lane-changers: EVA %.2f vs Social %.2f m' % (fe.mean(), fs.mean()))
