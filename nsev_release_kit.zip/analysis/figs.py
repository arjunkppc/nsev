import json, pickle, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
plt.rcParams.update({'font.family': 'DejaVu Serif', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
A = json.load(open('analysis.json')); CL = A['closed_loop']
PC = {'nocoord': '#8c8c8c', 'reactive': '#e0a030', 'pace_cv': '#5b8fd1', 'pace_social': '#9b6fc2', 'pace_eva': '#c0392b'}
PN = {'nocoord': 'No-Coord', 'reactive': 'Reactive-V2X', 'pace_cv': 'PACE (const. vel.)', 'pace_social': 'PACE (Social-Attn)', 'pace_eva': 'PACE (EVA-Net)'}
def save(n): plt.tight_layout(); plt.savefig(f'figs/{n}.png', dpi=200); plt.close()

# ---------- Fig 1 pipeline
fig, ax = plt.subplots(figsize=(12, 3.9)); ax.set_xlim(0, 12); ax.set_ylim(0.1, 4.1); ax.axis('off')
def box(x, y, w, h, t, b, fc):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.03,rounding_size=0.08', fc=fc, ec='#333', lw=1))
    ax.text(x + w / 2, y + h - 0.18, t, ha='center', va='top', weight='bold', fontsize=8.8)
    ax.text(x + w / 2, y + h - 0.5, b, ha='center', va='top', fontsize=7.4, linespacing=1.35)
def arr(x1, y1, x2, y2, ls='-'):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='-|>', mutation_scale=11, lw=1.1, color='#333', ls=ls))
box(0.2, 2.5, 2.2, 1.5, 'nuScenes scene', 'real vehicle tracks\n+ ego vehicle, 2 Hz\n20 s, Boston /\nSingapore', '#eaf2e3')
box(2.75, 2.5, 2.3, 1.5, 'EV injection', 'route = path of a real\nmoving vehicle, +250 m\nrun-up; EV starts\n40-100 m behind', '#e8f0fb')
box(5.4, 2.5, 2.5, 1.5, 'Reactive log replay', 'log replay until the driver\nperceives the EV (d_p, tau);\nyield / panic / stubborn;\nlogged followers take over', '#e8f0fb')
box(8.25, 2.5, 1.6, 1.5, 'Validity', 'discard spawn- and\nlog-conflict\nreplays\n(about 20%)', '#fdecea')
box(10.2, 2.5, 1.6, 1.5, 'Samples', 'Frenet frame\n(s, d); 2 s hist.,\n3 s future;\nreaction labels', '#fdf1e0')
for x1, x2 in [(2.4, 2.75), (5.05, 5.4), (7.9, 8.25), (9.85, 10.2)]: arr(x1, 3.25, x2, 3.25)
box(0.2, 0.2, 3.0, 1.55, 'Prediction (open loop)', 'EVA-Net vs Social-Attn, MLP,\nCV, CA; 3 seeds; scene-\nbootstrap CIs; stress tests\nA-D; domain randomisation', '#fdf1e0')
box(3.55, 0.2, 3.6, 1.55, 'Closed loop (same replays)', 'share rho of recorded vehicles are CVs;\ncoordinator commands CVs every 0.5 s;\nHDVs keep the human response model;\nidentical random numbers per policy', '#f3e8fb')
box(7.5, 0.2, 4.3, 1.55, 'Policies and metrics', 'No-Coord | Reactive-V2X | PACE (CV / Social / EVA)\nEV delay, disruption vs. the real log,\ncommand conflicts, collisions (simulated\nvs. logged), dev tuning -> held-out test', '#f3e8fb')
arr(11.0, 2.5, 1.7, 1.75, ls='--'); arr(6.65, 2.5, 5.35, 1.75, ls='--'); arr(7.15, 0.98, 7.5, 0.98)
save('fig01_pipeline')

# ---------- Fig 2 dataset
DS = A['datasets']; fig, ax = plt.subplots(1, 3, figsize=(12.5, 3.4))
sp = ['nsev_train', 'nsev_val', 'nsev_test']; lab = ['Train', 'Validation', 'Test']
v = [DS[s]['valid'] for s in sp]; lc = [DS[s].get('log_conflict', 0) for s in sp]; sc = [DS[s].get('spawn_conflict', 0) for s in sp]
ax[0].bar(lab, v, color='#5b8fd1', label='valid'); ax[0].bar(lab, lc, bottom=v, color='#e0a030', label='log conflict')
ax[0].bar(lab, sc, bottom=np.array(v) + lc, color='#c0392b', label='spawn conflict')
for i, s in enumerate(sp): ax[0].text(i, DS[s]['replays'] + 20, f"{DS[s]['samples']:,} samples", ha='center', fontsize=7.5)
ax[0].set_ylabel('EV injections (replays)'); ax[0].set_title('(a) Replay outcomes per split'); ax[0].legend(frameon=False, fontsize=7.5)
L = [l for l in json.load(open('nsev_test_log.json')) if 'discarded' not in l]
ax[1].hist([l['ev_mean_speed'] for l in L], bins=30, color='#9b6fc2'); ax[1].axvline(16, c='k', ls='--', lw=.8)
ax[1].set_xlabel('Mean EV speed over the scene (m/s)'); ax[1].set_ylabel('Replays'); ax[1].set_title('(b) Uncoordinated EV speed (test)')
tk = np.array([l['takeovers'] for l in L]); ax[2].bar(np.arange(0, tk.max() + 1), np.bincount(tk.astype(int)), color='#c0392b')
ax[2].set_xlabel('Drivers reacting to the EV per replay'); ax[2].set_ylabel('Replays'); ax[2].set_title('(c) Human reactions per replay (test)')
save('fig02_dataset')

# ---------- Fig 3 training curves
fig, ax = plt.subplots(1, 2, figsize=(11, 3.3))
for kind, K, c, n in [('pace', 6, '#c0392b', 'EVA-Net (K=6)'), ('social', 6, '#9b6fc2', 'Social-Attn (K=6)'), ('pace', 1, '#e67e22', 'EVA-Net (K=1)'), ('mlp', 1, '#7f8c8d', 'MLP (K=1)')]:
    for sd in range(3):
        cu = np.array(pickle.load(open(f'nsev_s{sd}_model_{kind}_K{K}.pkl', 'rb'))[4])
        ax[1].plot(cu[:, 0] + 1, cu[:, 2], color=c, alpha=.8, label=n if sd == 0 else None)
        ax[0].plot(cu[1:, 0] + 1, cu[1:, 1], color=c, alpha=.8, label=n if sd == 0 else None)
ax[0].set_title('(a) Training loss (Eq. 16), epochs 2-30'); ax[1].set_title('(b) Validation ADE + minADE (m), 3 seeds each')
for a in ax: a.set_xlabel('Epoch'); a.grid(alpha=.3)
ax[1].legend(frameon=False, fontsize=7.5); save('fig03_training')

# ---------- Fig 4 prediction table as bars
P = A['pred']; names = list(P); cols = ['#bbbbbb', '#999999', '#7f8c8d', '#9b6fc2', '#e67e22', '#c0392b']
fig, ax = plt.subplots(1, 4, figsize=(13, 3.3))
for i, (m, t, sc) in enumerate([('minADE', 'minADE$_6$ (m)', 1), ('minFDE', 'minFDE$_6$ (m)', 1), ('MR', 'Miss rate @2 m (%)', 100), ('AUC', 'Yield-intent AUROC', 1)]):
    vals = [P[n]['all'][m] * sc if not (m == 'AUC' and n in ('CV', 'CA')) else 0 for n in names]
    ax[i].bar(range(len(names)), vals, color=cols)
    for j, vv in enumerate(vals):
        if vv: ax[i].text(j, vv, f'{vv:.3f}' if sc == 1 else f'{vv:.1f}', ha='center', va='bottom', fontsize=6.5)
    ax[i].set_xticks(range(len(names))); ax[i].set_xticklabels(names, rotation=40, ha='right', fontsize=7); ax[i].set_title(f'({"abcd"[i]}) {t}')
    if m == 'AUC': ax[i].set_ylim(0.4, 1.0)
save('fig04_prediction')

# ---------- Fig 5 stratified with seed std
C = A['ci']['tables']; st = ['all', 'EV-reacting', 'not reacting', 'lane-changing']; md = ['Social-Attn (K=6)', 'EVA-Net (K=6)', 'MLP (K=1)', 'EVA-Net (K=1)']
mc = ['#9b6fc2', '#c0392b', '#7f8c8d', '#e67e22']; fig, ax = plt.subplots(1, 2, figsize=(11.5, 3.4)); w = .2
for j, m in enumerate(md):
    for a_, sub in [(0, [0, 1]), (1, [2, 3])]:
        if j not in sub: continue
        k = sub.index(j)
        ax[a_].bar(np.arange(4) + (k - .5) * w * 1.6, [C[s][m]['minFDE'][0] for s in st], w * 1.6, yerr=[C[s][m]['minFDE'][1] for s in st], color=mc[j], capsize=3, label=m)
cp = A['ci']['comparisons']
for a_, (x, y) in enumerate([('EVA-Net (K=6)', 'Social-Attn (K=6)'), ('EVA-Net (K=1)', 'MLP (K=1)')]):
    for i, s in enumerate(st):
        v = cp[f'{s}: {x} - {y}']; top = max(C[s][x]['minFDE'][0], C[s][y]['minFDE'][0])
        ax[a_].text(i, top * 1.05 + .02, f"{v['rel_pct']:+.1f}%" + ('*' if v['ci'][1] < 0 or v['ci'][0] > 0 else ''), ha='center', fontsize=7.5)
    ax[a_].set_xticks(range(4)); ax[a_].set_xticklabels(st); ax[a_].legend(frameon=False, fontsize=7.5); ax[a_].set_ylabel('minFDE (m), mean ± s.d. over 3 seeds')
ax[0].set_title('(a) Multimodal models (K = 6)'); ax[1].set_title('(b) Unimodal models (K = 1)'); save('fig05_strata')

# ---------- Fig 6 stress forest
S = A['stress']; k = 'EV-reacting: EVA-Net (K=6) - Social-Attn (K=6)'; T = ['nsev_test', 'stressA', 'stressB', 'stressC', 'stressD']
TL = ['Standard test', 'A: late / slow reaction', 'B: 40% panic braking', 'C: partial pull-over', 'D: extrapolation']
fig, ax = plt.subplots(1, 2, figsize=(12, 3.4))
for o, (tag, c, lb) in enumerate([('orig', '#c0392b', 'default training'), ('dr', '#2471a3', 'domain-randomised training')]):
    for i, t in enumerate(T):
        v = S[f'{tag}_{t}']['comparisons'][k]; base = S[f'{tag}_{t}']['tables']['EV-reacting']['Social-Attn (K=6)']['minFDE'][0]
        y = i + (o - .5) * 0.3; ax[0].errorbar(100 * v['diff'] / base, y, xerr=[[100 * (v['diff'] - v['ci'][0]) / base], [100 * (v['ci'][1] - v['diff']) / base]], fmt='o', color=c, capsize=3, label=lb if i == 0 else None)
ax[0].axvline(0, c='k', lw=.8); ax[0].set_yticks(range(5)); ax[0].set_yticklabels(TL); ax[0].invert_yaxis()
ax[0].set_xlabel('EVA-Net vs Social-Attn, minFDE$_6$ change (%) with 95% CI'); ax[0].set_title('(a) Reacting drivers: EV-aware advantage'); ax[0].legend(frameon=False, fontsize=7.5, loc='lower left')
w = .38
for o, (tag, c, lb) in enumerate([('orig', '#c0392b', 'EVA-Net, default'), ('dr', '#2471a3', 'EVA-Net, randomised')]):
    ax[1].bar(np.arange(5) + (o - .5) * w, [S[f'{tag}_{t}']['tables']['EV-reacting']['EVA-Net (K=6)']['minFDE'][0] for t in T], w,
              yerr=[S[f'{tag}_{t}']['tables']['EV-reacting']['EVA-Net (K=6)']['minFDE'][1] for t in T], color=c, capsize=2, label=lb)
ax[1].set_xticks(range(5)); ax[1].set_xticklabels(['Std', 'A', 'B', 'C', 'D']); ax[1].set_ylabel('minFDE$_6$ (m), reacting drivers')
ax[1].set_title('(b) Absolute error: default vs randomised training'); ax[1].legend(frameon=False, fontsize=7.5); save('fig06_stress')

# ---------- Fig 8 closed loop vs rho
rh = ['0.25', '0.5', '1.0']; x = [0.25, 0.5, 1.0]; fig, ax = plt.subplots(1, 3, figsize=(12.5, 3.4))
for p in ['nocoord', 'reactive', 'pace_cv', 'pace_eva']:
    ax[0].plot(x, [CL[r]['table'][p]['ev_delay'] for r in rh], 'o-', color=PC[p], label=PN[p])
    if p != 'nocoord':
        d = [CL[r]['cmp'][f'{p}-nocoord:lost_m'] for r in rh]
        ax[1].errorbar(x, [v['diff'] for v in d], yerr=[[v['diff'] - v['lo'] for v in d], [v['hi'] - v['diff'] for v in d]], fmt='o-', color=PC[p], capsize=3, label=PN[p])
        ax[2].plot(x, [CL[r]['table'][p]['cmd_conflicts'] for r in rh], 'o-', color=PC[p], label=PN[p])
ax[0].set_ylabel('EV delay (s)'); ax[0].set_title('(a) EV delay'); ax[1].axhline(0, c='k', lw=.8)
ax[1].set_ylabel('Extra metres lost vs. No-Coord'); ax[1].set_title('(b) Induced disruption (95% CI)'); ax[2].set_ylabel('Conflicts per run'); ax[2].set_title('(c) Conflicts caused by commanded CVs')
for a in ax: a.set_xlabel('CV penetration rate ρ'); a.set_xticks(x); a.grid(alpha=.3)
ax[0].legend(frameon=False, fontsize=7.5); save('fig08_closedloop_rho')

# ---------- Fig 9 PACE - Reactive forest
sets = [('0.25', 'ρ=0.25'), ('0.5', 'ρ=0.5'), ('1.0', 'ρ=1.0'), ('0.5_TL8', 'ρ=0.5, T$_{lead}$=8 s')]
fig, ax = plt.subplots(1, 3, figsize=(12.5, 3.2))
for i, (m, t) in enumerate([('ev_delay', 'EV delay (s)'), ('cmd_conflicts', 'Command conflicts per run'), ('lost_m', 'Disruption (m lost)')]):
    for j, (s, lb) in enumerate(sets):
        v = CL[s]['cmp'][f'pace_eva-reactive:{m}']
        ax[i].errorbar(v['diff'], j, xerr=[[v['diff'] - v['lo']], [v['hi'] - v['diff']]], fmt='o', color='#c0392b' if v['sig'] else '#999', capsize=3)
    ax[i].axvline(0, c='k', lw=.8); ax[i].set_yticks(range(4)); ax[i].set_yticklabels([s[1] for s in sets] if i == 0 else []); ax[i].invert_yaxis()
    ax[i].set_title(f'({"abc"[i]}) Δ {t}'); ax[i].set_xlabel('PACE (EVA-Net) − Reactive-V2X, 95% CI')
save('fig09_pace_vs_reactive')

# ---------- Fig 10 trade-off
fig, ax = plt.subplots(1, 2, figsize=(11.5, 3.8))
for s, mk in [('0.5', 'o'), ('1.0', 's'), ('0.5_TL8', '^')]:
    base = CL[s]['table']['nocoord']
    for p in ['reactive', 'pace_eva']:
        if s == '0.5_TL8' and p == 'reactive': continue
        t = CL[s]['table'][p]; red = 100 * (base['ev_delay'] - t['ev_delay']) / base['ev_delay']
        lbl = f"{PN[p]} ({'ρ=' + s.split('_')[0]}{', T=8 s' if 'TL8' in s else ''})"
        ax[0].scatter(red, t['lost_m'] - base['lost_m'], marker=mk, s=70, color=PC[p], edgecolor='k', label=lbl)
        ax[1].scatter(red, t['cmd_conflicts'], marker=mk, s=70, color=PC[p], edgecolor='k', label=lbl)
ax[0].set_ylabel('Induced disruption (extra m lost)'); ax[1].set_ylabel('Command conflicts per run')
for a in ax: a.set_xlabel('EV delay reduction vs No-Coord (%)'); a.grid(alpha=.3)
ax[0].set_title('(a) Speed vs disruption'); ax[1].set_title('(b) Speed vs conflicts'); ax[1].legend(frameon=False, fontsize=7, loc='upper left'); save('fig10_tradeoff')

# ---------- Fig 11 city split
fig, ax = plt.subplots(1, 2, figsize=(11, 3.3)); cities = ['boston', 'singapore']
for i, (key, t) in enumerate([('eva-reactive:delay', 'Δ EV delay, PACE − Reactive (s)'), ('eva-reactive:cmd_conf', 'Δ command conflicts, PACE − Reactive')]):
    for j, c in enumerate(cities):
        for k_, s in enumerate(rh):
            v = CL[s]['city'][c][key]; xpos = j * 4 + k_
            ax[i].bar(xpos, v['diff'], color=['#2471a3', '#16a085'][j], alpha=.5 + .25 * k_, yerr=[[v['diff'] - v['lo']], [v['hi'] - v['diff']]], capsize=3)
            if v['sig']:
                off = 0.01 if key.endswith('delay') else 0.006
                ax[i].text(xpos, (v['hi'] + off) if v['diff'] > 0 else (v['lo'] - 3 * off), '*', ha='center')
    ax[i].axhline(0, c='k', lw=.8); ax[i].set_xticks([0, 1, 2, 4, 5, 6]); ax[i].set_xticklabels(['ρ .25', 'ρ .5', 'ρ 1', 'ρ .25', 'ρ .5', 'ρ 1'])
    ax[i].text(1, ax[i].get_ylim()[0], 'Boston (right-hand)', ha='center', va='bottom', fontsize=8); ax[i].text(5, ax[i].get_ylim()[0], 'Singapore (left-hand)', ha='center', va='bottom', fontsize=8)
    ax[i].set_title(f'({"ab"[i]}) {t}')
save('fig11_city')

# ---------- Fig 12 safety
fig, ax = plt.subplots(figsize=(7.5, 3.2)); w = .18
for j, p in enumerate(['reactive', 'pace_cv', 'pace_eva']):
    ax.bar(np.arange(3) + (j - 1) * w * 2, [CL[s]['table'][p]['runs_coll_sim'] / CL[s]['n'] * 100 for s in rh], w, color=PC[p], label=f'{PN[p]}: simulated vehicle')
    ax.bar(np.arange(3) + (j - 1) * w * 2 + w, [CL[s]['table'][p]['runs_coll_logged'] / CL[s]['n'] * 100 for s in rh], w, color=PC[p], alpha=.4, hatch='//', label=f'{PN[p]}: logged (non-reactive)')
ax.set_xticks(range(3)); ax.set_xticklabels(['ρ = 0.25', 'ρ = 0.5', 'ρ = 1.0']); ax.set_ylabel('Runs with an EV collision (%)')
ax.set_title('EV collisions by involved vehicle (No-Coord = 0 by validity filter)'); ax.legend(frameon=False, fontsize=6.5, ncol=2); save('fig12_safety')
print('figures done')
