#!/bin/bash
# Build a clean, shareable copy of the NS-EV code from the working folder on the cluster.
# Usage (from the folder that holds this kit):
#   bash make_release.sh  [SRC=~/ARJUN/Multiagent/nsev]  [DEST=~/ARJUN/Multiagent/NS-EV]  [--with-results] [--with-models]
# Nothing in SRC is changed or deleted. DEST is created fresh.
set -e
KIT=$(cd "$(dirname "$0")" && pwd)
SRC=${SRC:-$HOME/ARJUN/Multiagent/nsev}
DEST=${DEST:-$HOME/ARJUN/Multiagent/NS-EV}
WITH_RESULTS=0; WITH_MODELS=0
for a in "$@"; do case $a in --with-results) WITH_RESULTS=1;; --with-models) WITH_MODELS=1;; esac; done
PY=${PY:-/apps/codes/anaconda2024/bin/python}

echo "Source : $SRC"; echo "Release: $DEST"
[ -d "$SRC" ] || { echo "ERROR: $SRC not found"; exit 1; }
if [ -e "$DEST" ]; then echo "ERROR: $DEST already exists - remove or rename it first"; exit 1; fi

# ---- 1. the final code actually used for the paper (all patches v2-v8 already applied in place)
CODE="features.py sim.py nsev_pipeline.py model.py train.py eval_pred.py compute_ci.py nsev_closedloop.py select_tl.py summarize_cl.py"
TOOLS="count_nuscenes_ev.py diag_coll.py"
for f in $CODE; do [ -f "$SRC/$f" ] || { echo "ERROR: missing $SRC/$f"; exit 1; }; done

# ---- 2. check that the copies are the FINAL (v8) versions, not older ones
chk() { grep -q -- "$2" "$SRC/$1" || { echo "ERROR: $1 does not contain the $3 - is this the final version?"; exit 1; }; }
chk nsev_pipeline.py "np.sign(fd\[j\]) if abs(fd\[j\]) >= 0.5" "v8 yield-direction fix"
chk nsev_pipeline.py "pulling over for the EV" "v7 comfortable-deceleration fix"
chk nsev_pipeline.py "RESP = dict(" "v5 response parameters"
chk nsev_pipeline.py "--randomize" "v6 domain randomisation"
chk nsev_closedloop.py "def yield_dir" "v8 closed-loop yield direction"
chk model.py "self.seed = seed" "v5 training seeds"
echo "OK: all files are the final v8 versions"

mkdir -p "$DEST"/{src,tools,scripts,analysis,docs/figures}
for f in $CODE; do cp "$SRC/$f" "$DEST/src/"; done
for f in $TOOLS; do [ -f "$SRC/$f" ] && cp "$SRC/$f" "$DEST/tools/" || echo "note: $f not found, skipped"; done
cp "$KIT"/analysis/*.py "$DEST/analysis/"
cp "$KIT"/scripts/run_all.sh "$DEST/scripts/"
cp "$KIT"/README.md "$KIT"/requirements.txt "$DEST/"
cp "$KIT"/gitignore "$DEST/.gitignore"
cp "$KIT"/docs/figures/* "$DEST/docs/figures/" 2>/dev/null || true

# ---- 3. optional: results and trained models from the v8 run
if [ $WITH_RESULTS = 1 ]; then
  mkdir -p "$DEST/results"
  for f in "$SRC"/ci_*.json "$SRC"/res_pred_nsev.json "$SRC"/nsev_*_log.json "$SRC"/stress*_log.json \
           "$SRC"/cl_dev_*.jsonl "$SRC"/cl_test_*.jsonl "$SRC"/cl_dev_selection.txt "$SRC"/chosen_tl.txt "$SRC"/cl_test_summary.txt; do
    [ -f "$f" ] && cp "$f" "$DEST/results/"; done
  echo "results copied: $(ls "$DEST/results" | wc -l) files"
fi
if [ $WITH_MODELS = 1 ]; then
  mkdir -p "$DEST/models"; cp "$SRC"/nsev_s?_model_*.pkl "$SRC"/nsevdr_s?_model_*.pkl "$DEST/models/" 2>/dev/null || true
  echo "models copied: $(ls "$DEST/models" | wc -l) files"
fi

# ---- 4. remove personal paths and caches from the copies
grep -rl "g700515\|/home/[a-z0-9_]*/ARJUN" "$DEST" 2>/dev/null | while read f; do
  sed -i -e 's#/home/[a-z0-9_]*/ARJUN/Multiagent/nuscenes#/path/to/nuscenes#g' -e 's#/home/[a-z0-9_]*/ARJUN#/path/to/project#g' "$f"
  echo "personal path removed from: ${f#$DEST/}"; done
find "$DEST" -name "__pycache__" -prune -exec rm -rf {} + ; find "$DEST" -name "*.pyc" -delete

# ---- 5. syntax check of every Python file
for f in "$DEST"/src/*.py "$DEST"/analysis/*.py "$DEST"/tools/*.py; do [ -f "$f" ] || continue; $PY -m py_compile "$f"; done
find "$DEST" -name "__pycache__" -prune -exec rm -rf {} +
echo "OK: all Python files compile"

# ---- 6. record the exact package versions used
$PY -m pip freeze 2>/dev/null | grep -i -E '^(numpy|scipy|autograd|matplotlib|nuscenes-devkit)==' > "$DEST/environment.txt" || true
$PY --version >> "$DEST/environment.txt" 2>&1
echo "versions recorded in environment.txt:"; cat "$DEST/environment.txt"

# ---- 7. archive
cd "$(dirname "$DEST")"; tar czf "$(basename "$DEST").tar.gz" "$(basename "$DEST")"
echo; echo "Done. Folder : $DEST"; echo "      Archive: $(dirname "$DEST")/$(basename "$DEST").tar.gz"
du -sh "$DEST"; find "$DEST" -type f | sed "s#$DEST/##" | sort
