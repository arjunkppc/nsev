#!/bin/bash
#SBATCH --job-name=nsev
#SBATCH --cpus-per-task=8
#SBATCH --mem=48G
#SBATCH --time=24:00:00
#SBATCH --output=nsev_%j.log
# Reproduces every number and figure of the paper. Resumable: each step is skipped if its output exists.
# Usage:  DATAROOT=/path/to/nuscenes  bash scripts/run_all.sh        (or: sbatch --export=ALL,DATAROOT=... scripts/run_all.sh)
# Outputs go to ./work (override with WORK=...).
set -e
REPO=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
[ -n "$SLURM_SUBMIT_DIR" ] && [ -f "$SLURM_SUBMIT_DIR/src/model.py" ] && REPO=$SLURM_SUBMIT_DIR
DATAROOT=${DATAROOT:?set DATAROOT to the nuScenes folder that contains v1.0-trainval/}
PY=${PY:-python}
WORK=${WORK:-$REPO/work}; mkdir -p "$WORK/figs"; cd "$WORK"
export PYTHONPATH=$REPO/src:$PYTHONPATH
S=$REPO/src
step() { echo; echo "=== [$(date '+%H:%M:%S')] $*"; }

step "1. NS-EV datasets: Stages 1-5 (default response model)"
[ -f nsev_train.npz ] || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split train_fit     --out nsev_train.npz --injections 3 --seed 0
[ -f nsev_val.npz ]   || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split train_holdout --out nsev_val.npz   --injections 3 --seed 1
[ -f nsev_test.npz ]  || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split val           --out nsev_test.npz  --injections 3 --seed 2

step "2. Stage 6: EVA-Net and reference models, 4 models x 3 seeds"
for sd in 0 1 2; do
  for cfg in "pace 6" "pace 1" "social 6" "mlp 1"; do
    set -- $cfg; f=nsev_s${sd}_model_$1_K$2.pkl
    [ -f $f ] || $PY $S/train.py $1 $2 30 nsev_train.npz nsev_val.npz $f $sd
  done
done

step "3. Stage 8 (open loop): prediction metrics + scene-bootstrap CIs"
for f in nsev_s0_model_*.pkl; do t=nsev_${f#nsev_s0_}; [ -f $t ] || cp $f $t; done
[ -f res_pred_nsev.json ] || $PY $S/eval_pred.py nsev_test.npz nsev_ res_pred_nsev.json
[ -f ci_results.json ]    || $PY $S/compute_ci.py nsev_test.npz nsev_test_log.json "0 1 2" nsev_s all ci_results.json

step "4. Domain-randomised data (Eq. 13) + EVA-Net / Social-Attn x 3 seeds"
[ -f nsevdr_train.npz ] || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split train_fit     --out nsevdr_train.npz --injections 3 --seed 10 --randomize
[ -f nsevdr_val.npz ]   || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split train_holdout --out nsevdr_val.npz   --injections 3 --seed 11 --randomize
for sd in 0 1 2; do for k in pace social; do
  f=nsevdr_s${sd}_model_${k}_K6.pkl; [ -f $f ] || $PY $S/train.py $k 6 30 nsevdr_train.npz nsevdr_val.npz $f $sd
done; done

step "5. Stress-test sets A-D"
[ -f stressA.npz ] || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split val --out stressA.npz --injections 3 --seed 2 --dp_lo 35 --dp_hi 80 --react_mu 2.2
[ -f stressB.npz ] || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split val --out stressB.npz --injections 3 --seed 2 --freeze_p 0.40
[ -f stressC.npz ] || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split val --out stressC.npz --injections 3 --seed 2 --shift 2.2
[ -f stressD.npz ] || $PY $S/nsev_pipeline.py --dataroot $DATAROOT --split val --out stressD.npz --injections 3 --seed 2 --dp_lo 25 --dp_hi 55 --react_mu 2.8 --freeze_p 0.5 --shift 1.6

step "6. CIs for default and randomised models on test + stress sets"
for T in nsev_test stressA stressB stressC stressD; do
  [ -f ci_orig_$T.json ] || $PY $S/compute_ci.py $T.npz ${T}_log.json "0 1 2" nsev_s   k6 ci_orig_$T.json
  [ -f ci_dr_$T.json ]   || $PY $S/compute_ci.py $T.npz ${T}_log.json "0 1 2" nsevdr_s k6 ci_dr_$T.json
done

step "7. Stage 7 on development scenes: T_lead 8/15/30 s + pre-registered selection"
for TL in 8 15 30; do
  f=cl_dev_TL${TL}_TH0.3.jsonl
  [ -f $f ] || $PY $S/nsev_closedloop.py --dataroot $DATAROOT --split train_holdout --rho 0.5 --injections 2 --t_lead $TL --theta_r 0.3 \
      --policies nocoord,reactive,pace_cv,pace_eva --eva nsevdr_s0_model_pace_K6.pkl --social nsevdr_s0_model_social_K6.pkl --out $f
done
$PY $S/select_tl.py | tee cl_dev_selection.txt
TL=$(cat chosen_tl.txt); SEC=8; [ "$TL" = "8" ] && SEC=15

step "8. Stage 7 + 8 (closed loop) on held-out test scenes (T_lead=$TL; secondary $SEC s at rho=0.5)"
for RHO in 0.25 0.5 1.0; do
  f=cl_test_rho${RHO}.jsonl
  [ -f $f ] || $PY $S/nsev_closedloop.py --dataroot $DATAROOT --split val --rho $RHO --injections 3 --t_lead $TL --theta_r 0.3 \
      --eva nsevdr_s0_model_pace_K6.pkl --social nsevdr_s0_model_social_K6.pkl --out $f
done
f=cl_test_rho0.5_TL${SEC}.jsonl
[ -f $f ] || $PY $S/nsev_closedloop.py --dataroot $DATAROOT --split val --rho 0.5 --injections 3 --t_lead $SEC --theta_r 0.3 \
    --eva nsevdr_s0_model_pace_K6.pkl --social nsevdr_s0_model_social_K6.pkl --out $f

step "9. Closed-loop summaries"
{ for f in cl_test_rho0.25.jsonl cl_test_rho0.5.jsonl cl_test_rho1.0.jsonl cl_test_rho0.5_TL${SEC}.jsonl; do
    $PY $S/summarize_cl.py $f nocoord; $PY $S/summarize_cl.py $f reactive; echo; done; } > cl_test_summary.txt

step "10. Paper statistics and result figures"
$PY $REPO/analysis/analyze.py && $PY $REPO/analysis/figs.py && $PY $REPO/analysis/fig7.py
echo "ALL DONE - results in $WORK, figures in $WORK/figs"
